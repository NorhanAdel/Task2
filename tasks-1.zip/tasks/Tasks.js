//////task1
// 
const fs = require("fs");
const person = {
  fname: "Ahmed",
  lname: "Hossam",
  age: 20,
  city: "Alex",
};
const personJson = JSON.stringify(person);
fs.writeFileSync("person.json", personJson);

const fileData = fs.readFileSync("person.json", "utf-8");

const retrievedPerson = JSON.parse(fileData);

retrievedPerson.fname = "Adel";
retrievedPerson.lname = "Ahmed";
retrievedPerson.age = 40;
retrievedPerson.city = "Cairo";

const updatedPersonJson = JSON.stringify(retrievedPerson);

fs.writeFileSync("updatedPerson.json", updatedPersonJson);
/////////////// task2

const persons = [
  { id: 1, fname: 'norhan', lname: 'adel', age: 20, city: 'banha' },
  { id: 2, fname: 'mohamed', lname: 'Agwa', age: 18, city: 'cairo' },
  { id: 3, fname: 'nora', lname: 'mohamed', age: 40, city: 'ismailia' },
  { id: 4, fname: 'mohamed', lname: 'nora', age: 35, city: 'alex' },
  { id: 5, fname: 'mohamed', lname: 'mohamed', age: 28, city: 'aswan' },

];

const filteredPersons = persons.filter(person => person.id !== 4 && person.id !== 6);

const personList = filteredPersons.map(person => {
  return {
    fname: person.fname,
    lname: person.lname,
    city: person.city
  };
});

const fifthPerson = filteredPersons.find(person => person.id === 5);
